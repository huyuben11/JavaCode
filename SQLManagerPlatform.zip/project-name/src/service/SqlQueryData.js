import fetch from '../config/fetch'
/**
 * 获得SQL信息
 */
export const Sqlquery = (data) => fetch('/sqlmanager/sqlquery', data, 'POST')
/**
 * 获得SQL提交人信息
 */
export const getSqlquerycommits = (data) => fetch('/person/getcommits', data, 'POST')
/**
 * 获得选择器SQL类型
 */
export const getSqlquerytypes = (data) => fetch('/sqlmanager/getsqltypes', data, 'POST')
/**
 * 获得选择器涉及得表
 */
export const getSqlquerytables = (data) => fetch('/sqlmanager/gettables', data, 'POST')
/**
 * 获得Query可查询产品和版本列表
 */
export const getSqlqueryavigation = (data) => fetch('/sqlmanager/getavailableversion', data, 'POST')
