// import {getStore,removeStore} from 'localstorage'
import fetch from '../config/fetch'
/**
 * 获取用户信息
 */
export const getUser = (data) => fetch('/empno/login', data, 'POST')
/**
 * 获得首页提交列表信息
 */
export const getHomeinfo = (data) => fetch('/sqlmanager/gethomecommit', data, 'POST')
/**
 * 获得所有可用版本信息
 */
export const getAvailableVersion = (data) => fetch('/sqlmanager/getavailableversion', data, 'POST')
/**
 * 从本地获取用户信息
 */
export const getUserLocal = () => sessionStorage.getItem('sqlmanageruser')
/**
 * 从本地删除用户信息
 */
export const remoreUserLocal = () => sessionStorage.removeItem('sqlmanageruser')
/**
 * 在本地存储用户信息
 */
export const setUserLocal = (obj) => sessionStorage.setItem('sqlmanageruser', JSON.stringify(obj))
/**
 * 在本地存储网页标题信息
 */
export const setTitleLocal = (title) => sessionStorage.setItem('sqlpagetitle', title)
/**
 * 从本地获得网页标题信息
 */
export const getTitleLocal = (title) => sessionStorage.getItem('sqlpagetitle')
/**
 * 获得产品维护信息
 */
export const getprojectinfo = (data) => fetch('/sqlmanager/queryprojectlist', data, 'POST')
/**
 * 添加产品
 */
export const addproject = (data) => fetch('/sqlmanager/addproject', data, 'POST')
