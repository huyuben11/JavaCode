import fetch from '../config/fetch'
/**
 * 获取可用版本列表
 */
export const getversion = () => fetch('/sqlmanager/getavailableversion', null, 'POST')
/**
 * 获得某个版本的提交记录
 * @param {*} data
 */
export const getversioncommitrecord = (data) => fetch('/sqlmanager/getcommitrecord', data, 'POST')
/**
 * 停用/启用版本
 */
export const editVersionHalt = (data) => fetch('/sqlmanager/editversionhalt', data, 'POST')
/**
 * 获得版本维护信息
 */
export const getVersionInfo = (data) => fetch('/sqlmanager/getprojectinfolist', data, 'POST')
/**
 * 添加版本
 */
export const addversion = (data) => fetch('/sqlmanager/addversion', data, 'POST')
/**
 * 修改版本
 */
export const updateversion = (data) => fetch('/sqlmanager/editversion', data, 'POST')
