<template>
  <el-container class="sqlquery-container sqlquery-menu">
    <el-aside width="201px">
      <el-menu  :default-openeds="openeds">
        <el-submenu
          v-for="project in projectlist"
          :index="project.project_name"
          :key="project.project_name">
          <template slot="title">
            <i class="el-icon-tickets"/>
            <span>{{project.project_descript}}</span>
          </template>
          <el-menu-item v-on:click="Messageversion(project.project_name, version.version_name)"
            v-for="version in project.versionlist"
            :index="version.version_name"
            :key="version.version_name">
            {{version.version_descript}}
          </el-menu-item>
        </el-submenu>
      </el-menu>
    </el-aside>
    <!--main 头部-->
    <el-container>
      <el-header class="sqlquery-header" style="height: 146px;">
        <el-row>
          <span>
            <span class="sqlquery-header-title">查询条件</span>
            <span class="sqlquery-header-sp">&nbsp;|&nbsp;</span>
            <span v-if="selectedProjectName != ''" class="sqlquery-header-version">{{selectedProjectName}}-{{selectedVersionName}}</span>
            <span v-else class="sqlquery-header-version-error">请先选择产品版本</span>
          </span>
        </el-row>
        <el-row class="sqlquery-condition-panel">
          <!--日期显示-->
          <el-col :span="4" class="sqlquery-condition-container">
            <el-col class="sqlquery-condition-panel-text">
              日期选择
            </el-col>
            <el-date-picker class="text-time"
              v-model="searchDate"
              type="daterange"
              unlink-panels
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              :picker-options="pickerOptions2">
            </el-date-picker>
          </el-col>
          <!--提交人-->
          <el-col :span="4" class="sqlquery-condition-container">
            <el-col class="sqlquery-condition-panel-text">
              提交人
            </el-col>
            <el-select
              v-model="searchCommitter"
              clearable placeholder="请选择提交人"
              class="text-person">
              <el-option
                v-for="committer in sqlgetpersoncommitlist"
                :key="committer.empno"
                :label="committer.name"
                :value="committer.empno">
              </el-option>
            </el-select>
          </el-col>
          <el-col :span="4" class="sqlquery-condition-container">
            <el-col class="sqlquery-condition-panel-text">
              SQL类型
            </el-col>
            <el-select
              v-model="searchType"
              value-format="yyyy-MM-dd"
              clearable placeholder="SQL类型"
              class="text-sqltype">
              <el-option
                v-for="item in sqlgetquerytypelist"
                :key="item.type"
                :label="item.type"
                :value="item.type">
              </el-option>
            </el-select>
          </el-col>
          <!--涉及表-->
          <el-col :span="4" class="sqlquery-condition-container">
            <el-col class="sqlquery-condition-panel-text">
              涉及表
            </el-col>
            <el-select
              v-model="searchInvolveTable"
              clearable placeholder="涉及表"
              class="text-sqltable">
              <el-option
                v-for="table in sqlgetquerytableslist"
                :key="table.tablename"
                :label="table.tablename"
                :value="table.tablename">
              </el-option>
            </el-select>
          </el-col>
          <!--执行时间-->
          <el-col :span="4" class="sqlquery-condition-container">
            <el-col class="sqlquery-condition-panel-text">
              执行时间超过
            </el-col>
            <el-input class="text-time"
              placeholder="执行时间超过"
              v-model="searchExecutionTime"
              clearable>
            </el-input>
          </el-col>
          <el-col :span="4" class="sqlquery-condition-container">
            <el-button  class="text-button" type="primary" v-on:click="seeMessage">查询数据</el-button>
          </el-col>
        </el-row>
      </el-header>
      <!--主显示-->
      <el-main class="sqlquery-mian">
        <el-row v-for="sql in sqlquerylist" :key="sql.uuid" class="card-panel">
          <el-row>
            <el-col :span="24" class="commitdate">
              <span>
                Commits on &nbsp; {{sql.crttime}} &nbsp; {{sql.crtby}} &nbsp;&nbsp;
              </span>
              <span v-if="sql.cby !== ''">
                Changed on {{sql.changed}} &nbsp; {{sql.cby}}
              </span>
            </el-col>
          </el-row>
          <el-card shadow="always" class="card-detail">
            <el-row :span="24">
              <el-col :span="16" type="flex">
                <el-row class="card-row">
                  <el-col :span="4">
                    <span>
                      SQL类型
                      <span class="text-value">
                        &nbsp;&nbsp;{{sql.type}}
                      </span>
                    </span>
                  </el-col>
                  <el-col :span="6">
                    <span>
                      测试库执行时间
                      <span v-if="sql.exectime >= 100" class="text-toolong">
                        &nbsp;&nbsp;{{sql.exectime}} ms
                      </span>
                      <span v-else class="text-value">
                        &nbsp;&nbsp;{{sql.exectime}} ms
                      </span>
                    </span>
                  </el-col>
                  <!-- <el-col :span="6">
                    <span>
                      查看关联SQL {{sql.linksql}}
                    </span>
                  </el-col> -->
                </el-row>
                <el-row class="card-row">
                  <span>
                    涉及表
                    <span class="text-involve">
                      {{sql.involvetables}}
                    </span>
                  </span>
                </el-row>
              </el-col>
              <el-col :span="8" class="card-btn-panel">
                <el-button class="text-button1" type="primary"  @click="showInfo=true,parameter=sql.uuid">详细</el-button>
                <el-button class="text-button1" type="primary" >关联</el-button>
                <el-button class="text-button1" type="primary" >删除</el-button>
              </el-col>
            </el-row>
            <hr class="hr"/>
            <el-row>
              <el-col :span="1">
                SQL
              </el-col>
              <el-col :span="23" class="sql">
                <span v-html="sql.sql">{{sql.sql}}</span>
              </el-col>
            </el-row>
            <el-dialog v-if="sql.uuid==parameter" class="sqlquery"
              :visible.sync="showInfo"
              append-to-body="true">
              <div slot="title">完整SQL</div>
              <el-input
                type="textarea"
                v-html="sql.sql">
                {{sql.sql}}
              </el-input>
              <div slot="footer">
                <el-button type="primary" @click="showInfo = false">退 出</el-button>
              </div>
            </el-dialog>
          </el-card>
        </el-row>
      </el-main>
      <el-footer class="paging">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="currentPage"
          :page-sizes="[pagesize]"
          :page-size="pagesize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="sqlsourse.length">
        </el-pagination>
      </el-footer>
    </el-container>
  </el-container>
</template>

<script>
import { Sqlquery, getSqlquerycommits, getSqlquerytypes, getSqlquerytables, getSqlqueryavigation } from '@/service/SqlQueryData'
import { formatDate } from '@/config/utils'

export default {
  data () {
    return {
      // 是否显示为加载中
      loading: false,
      // 默认导航栏打开节点
      openeds: [
        'XMS'
      ],
      // 选择的导航栏产品代码
      selectedProjectName: '',
      // 选择的导航栏版本代码
      selectedVersionName: '',
      // 查询条件-开始时间&结束时间
      searchDate: '',
      // 查询条件-提交人
      searchCommitter: '',
      // 查询条件-sql类型
      searchType: '',
      // 查询条件-涉及表
      searchInvolveTable: '',
      // 查询条件-执行时间
      searchExecutionTime: '',
      // 产品版本列表
      projectlist: [],
      // 查询完整结果
      sqlquerylist: [],
      // 查询结果分页
      sqlsourse: [],
      versioninfomation: '',
      currentPage: 1,
      showInfo: false,
      parameter: 0,
      parinfomation: '',
      selectsqlinfomation: '',
      sqlgetpersoncommitlist: [],
      sqlgetquerytypelist: [],
      sqlgetquerytableslist: [],
      pagesize: 4, // 显示得数据
      pickerOptions2: {
        shortcuts: [{
          text: '最近一周',
          onClick (picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近一个月',
          onClick (picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近三个月',
          onClick (picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
            picker.$emit('pick', [start, end])
          }
        }]
      }
    }
  },
  methods: {
    seeMessage () {
      if (this.selectedProjectName === '' || this.selectedVersionName === '') {
        this.$message({
          type: 'error',
          showClose: true,
          message: '请先选择产品版本'
        })
      } else {
        this.sqlquerylist = []
        this.sqlsourse = []
        this.getinfomation()
      }
    },
    Messageversion (projectName, versionName) {
      console.log(projectName)
      console.log(versionName)
      this.selectedProjectName = projectName
      this.selectedVersionName = versionName
      this.sqlquerylist = []
      this.sqlsourse = []
    },
    handleSizeChange (val) {
      console.log(`每页 ${val} 条`)
    },
    handleCurrentChange (val) {
      console.log(`当前页: ${val} `)
      this.currentPage = val
      this.sqlquerylist = this.sqlsourse.slice(this.pagesize * (this.currentPage - 1), this.pagesize * this.currentPage)
    },
    async getinfomation () {
      this.loading = true
      var begindate = ''
      var enddate = ''
      if (this.searchDate !== null && this.searchDate !== '') {
        begindate = formatDate(this.searchDate[0], 'yyyy-MM-dd')
        enddate = formatDate(this.searchDate[1], 'yyyy-MM-dd')
      }
      var requestdata = { 'begindate': begindate, 'enddate': enddate, 'committer': this.searchCommitter, 'sqltype': this.searchType, 'involvetable': this.searchInvolveTable, 'exectime': this.searchExecutionTime }
      // console.log(requestdata)
      await Sqlquery(requestdata).then(res => {
        this.sqlquerylist = res.sqlquerylist
        for (var i = 0; i < this.sqlquerylist.length; i++) {
          this.sqlquerylist[i].sql = this.sqlquerylist[i].sql.replace(new RegExp('SELECT', 'gm'), '<span style="color: blue;">SELECT</span>')
          this.sqlquerylist[i].sql = this.sqlquerylist[i].sql.replace(new RegExp('INSERT', 'gm'), '<span style="color: blue;">INSERT</span>')
          this.sqlquerylist[i].sql = this.sqlquerylist[i].sql.replace(new RegExp('insert', 'gm'), '<span style="color: blue;">INSERT</span>')
          this.sqlquerylist[i].sql = this.sqlquerylist[i].sql.replace(new RegExp('from', 'gm'), '<span style="color: blue;">FROM</span>')
          this.sqlquerylist[i].sql = this.sqlquerylist[i].sql.replace(new RegExp('FROM', 'gm'), '<span style="color: blue;">FROM</span>')
          this.sqlquerylist[i].sql = this.sqlquerylist[i].sql.replace(new RegExp('where', 'gm'), '<span style="color: blue;">WHERE</span>')
          this.sqlquerylist[i].sql = this.sqlquerylist[i].sql.replace(new RegExp('WHERE', 'gm'), '<span style="color: blue;">WHERE</span>')
          this.sqlquerylist[i].sql = this.sqlquerylist[i].sql.replace(new RegExp('delete', 'gm'), '<span style="color: blue;">DELETE</span>')
          this.sqlquerylist[i].sql = this.sqlquerylist[i].sql.replace(new RegExp('DELETE', 'gm'), '<span style="color: blue;">DELETE</span>')
          this.sqlquerylist[i].sql = this.sqlquerylist[i].sql.replace(new RegExp('values', 'gm'), '<span style="color: blue;">VALUES</span>')
          this.sqlquerylist[i].sql = this.sqlquerylist[i].sql.replace(new RegExp('VALUES', 'gm'), '<span style="color: blue;">VALUES</span>')
          this.sqlquerylist[i].sql = this.sqlquerylist[i].sql.replace(new RegExp('INTO', 'gm'), '<span style="color: blue;">INTO</span>')
          this.sqlquerylist[i].sql = this.sqlquerylist[i].sql.replace(new RegExp('into', 'gm'), '<span style="color: blue;">INTO</span>')
          this.sqlquerylist[i].sql = this.sqlquerylist[i].sql.replace(new RegExp('null', 'gm'), '<span style="color: blue;">NULL</span>')
          this.sqlquerylist[i].sql = this.sqlquerylist[i].sql.replace(new RegExp('NULL', 'gm'), '<span style="color: blue;">NULL</span>')
          var slice = this.sqlquerylist[i].sql.split("'")
          var convertsql = ''
          for (var s = 0; s < slice.length; s++) {
            if (s % 2 === 1) {
              convertsql +=
                '<span style="color: Red;">' + "'" + slice[s] + "'" + '</span>'
            } else {
              convertsql += slice[s]
            }
          }
          this.sqlquerylist[i].sql = convertsql
          this.sqlsourse[i] = this.sqlquerylist[i]
        }
        this.sqlquerylist = this.sqlsourse.slice(this.pagesize * (this.currentPage - 1), this.pagesize * this.currentPage)
      })
      this.loading = false
    },
    async getcommit () {
      await getSqlquerycommits().then(res => {
        this.sqlgetpersoncommitlist = res.sqlgetpersoncommits
        // console.log(this.sqlgetpersoncommitslist)
      })
    },
    async getsqltype () {
      await getSqlquerytypes().then(res => {
        this.sqlgetquerytypelist = res.sqlgetsqltypes
        // console.log(this.sqlgetquerytypelist)
      })
    },
    async getsqltable () {
      await getSqlquerytables().then(res => {
        this.sqlgetquerytableslist = res.sqlgettables
        // console.log(this.sqlgetquerytableslist)
      })
    },
    async getnaversionlist () {
      await getSqlqueryavigation().then(res => {
        this.projectlist = res.projects
      })
    }
  },
  mounted () {
    this.getcommit()
    this.getsqltype()
    this.getsqltable()
    this.getnaversionlist()
  }
}
</script>

<style lang="scss" scoped>
.sqlquery-container {
  height: 100%;
  .sqlquery-header {
    .sqlquery-header-title {
      padding: 0 20px;
      height: 60px;
      line-height: 60px;
      font-weight: 400;
      font-size: 20px;
    }
    .sqlquery-header-sp {
      height: 60px;
      line-height: 60px;
      font-weight: 100;
      font-size: 20px;
    }
    .sqlquery-header-version {
      height: 60px;
      line-height: 60px;
      font-weight: 100;
      font-size: 16px;
    }
    .sqlquery-header-version-error {
      height: 60px;
      line-height: 60px;
      font-weight: 100;
      font-size: 16px;
      color: red;
    }
    .sqlquery-condition-panel {
      height: 85px;
      background: rgb(253, 250, 250);
      border-top: solid 1px #e6e6e6;
      border-bottom: solid 1px #e6e6e6;
      padding-left: 20px;
      .sqlquery-condition-container {
        padding: 0 20px 28px 0;
        .sqlquery-condition-panel-text {
          padding-top: 6px;
          padding-bottom: 6px;
          font-size: 13px;
          font-weight: 100;
        }
        .text-time {
          width: 100%;
          height: 40px;
        }
        .text-person {
          width: 100%;
          height: 40px;
        }
        .text-sqltype {
          width: 100%;
          height: 40px;
        }
        .text-sqltable {
          width: 100%;
          height: 40px;
        }
        .text-button {
          margin-top: 24px;
          width: 120px;
          height: 44px;
        }
      }
    }
  }
  .sqlquery-mian {
    .card-panel {
      padding-top: 10px;
      padding-left: 10px;
      padding-right: 10px;
      .commitdate {
        font-size: 14px;
        color: gray;
        text-indent: 10px;
        padding-bottom: 5px;
      }
      .card-detail {
        font-size: 13px;
        .card-row {
          margin-bottom: 5px;
          .text-value {
            color: cornflowerblue;
            text-indent: 20px;
          }
          .text-involve {
            color: cornflowerblue;
            margin-left: 20px;
          }
          .text-toolong {
            color: red;
            text-indent: 20px;
            font-size: 16px;
            font-weight: 400;
          }
        }
        .card-btn-panel {
          text-align: right;
        }
        .hr {
          height: 1px;
          border: none;
          border-top: 1px dashed lightgray;
        }
        .sql {
          // color: red;
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-line-clamp: 3;
          -webkit-box-orient: vertical;
        }
      }
    }
  }
  .paging {
    height: 60px;
    text-align: center;
  }
}
</style>

<style lang="scss">
.sqlquery-menu {
  .el-aside {
    border-right: solid 1px #e6e6e6;
  }
  .el-header {
    padding: 0 0px;
  }
  .el-main {
    padding: 0 0px;
  }
  .el-menu {
    border-right: solid 0px #e6e6e6;
  }
  .el-submenu__title {
    height: 44px;
    line-height: 44px;
    font-size: 12px;
    font-weight: 700;
  }
  .el-menu-item {
    height: 44px;
    line-height: 44px;
    font-size: 12px;
  }
}
.sqlquery .el-dialog__header {
  padding: 0px 0px 0px 0px;
  font-size: 25px;
  text-align: center;
  background-color: gray;
  font-weight: bold;
  color: white;
  height: 60px;
  line-height: 60px;
}
</style>
