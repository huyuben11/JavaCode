<template>
  <div>
      Auth
  </div>
</template>

<script>
export default {
  methods: {
  }
}
</script>
