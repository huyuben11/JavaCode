<template>
  <el-container class="container">
    <el-main>
      <el-row class="main">
        <el-row class="information">
          <span class="title">产品列表</span>
        </el-row>
        <el-row class="infor" :span="24">
          <el-col :span="12">
            <el-button type="primary" @click="showDialog=true" round>＋新增产品</el-button>
          </el-col>
          <el-col :span="12">
            <el-input placeholder="请输入内容" class="search" suffix-icon="el-icon-search" v-model="searchInput"/>
          </el-col>
        </el-row>
        <el-row class="tableSet" v-loading="loading">
          <el-table :data="tableData" class="data" max-height="500">
            <el-table-column prop="projectName" label="产品代码" />
            <el-table-column prop="projectDescript" label="产品描述" />
            <el-table-column prop="crttime" label="创建时间"/>
            <el-table-column prop="version" label="版本数"/>
            <el-table-column prop="newVersion" label="最新版本号" />
            <el-table-column prop="operation" label="操作" width="180">
              <template slot-scope="scope">
                <el-button type="primary" class="button" @click="handleVersionMaintain(scope.$index,scope.row)">></el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-row>
        <el-dialog class="sqldetail"
          :visible.sync="showDialog"
          append-to-body>
          <div slot="title">
            新增产品
          </div>
          <div class="add-dialog">
            <el-form :model="AddProjectInfo" ref="AddProjectInfo" :rules="AddProjectRule">
              <el-row class="dialog-content" :span="24">
                <el-col :span="3">
                  <span>
                    产品代码
                  </span>
                </el-col>
                <el-col :span="21">
                  <el-form-item prop="newProjectName" >
                    <el-input v-model="AddProjectInfo.newProjectName" class="dialog-code" placeholder="产品代码" />
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row class="dialog-content" :span="24">
                <el-col :span="3">
                  <span>
                    产品描述
                  </span>
                </el-col>
                <el-col :span="21">
                  <el-form-item prop="newProjectDescript" >
                    <el-input v-model="AddProjectInfo.newProjectDescript" class="dialog-descript" placeholder="产品描述" />
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
          </div>
          <div slot="footer">
            <el-button type="primary" @click="addprojects()" round>
              保&nbsp;存
            </el-button>
            <el-button  @click="showDialog = false" round>
              退&nbsp;出
            </el-button>
          </div>
        </el-dialog>
      </el-row>
    </el-main>
    <el-footer class="page">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        layout="prev, pager, next"
        :total="tableSearchResult.length"
        :page-size="pagesize">
      </el-pagination>
    </el-footer>
  </el-container>
</template>

<script>
import { getprojectinfo, addproject } from '@/service/getData'
export default {
  data () {
    return {
      // 表格数据
      tableData: [],
      // 接口返回原始数据
      table: [],
      // 搜索结果数据
      tableSearchResult: [],
      // 当前页码
      currentPage: 1,
      // 总页数
      pagesize: 6,
      // 是否关闭弹窗
      showDialog: false,
      // 弹窗数据源
      AddProjectInfo: {
        newProjectName: '',
        newProjectDescript: ''
      },
      // 弹窗校验规则
      AddProjectRule: {
        newProjectName: [
          { required: true, message: '请输入产品代码', trigger: 'blur' }
        ],
        newProjectDescript: [
          { required: true, message: '请输入产品描述', trigger: 'blur' }
        ]
      },
      // 搜索字符串
      searchInput: '',
      // 是否显示为加载
      loading: false
    }
  },
  methods: {
    handleVersionMaintain (index, row) {
      console.log(row.projectName)
      this.$router.push({ name: 'versionmaintain', params: { projectname: row.projectName } })
    },
    handleSizeChange (val) {
      console.log(`每页 ${val} 条`)
    },
    handleCurrentChange (val) {
      this.currentPage = val
      this.tableData = this.tableSearchResult.slice(this.pagesize * (this.currentPage - 1), this.pagesize * this.currentPage)
    },
    async getinfomation () {
      this.loading = true
      await getprojectinfo().then((res) => {
        this.table = res.tableData
        this.tableSearchResult = res.tableData
        this.tableData = this.tableSearchResult.slice(this.pagesize * (this.currentPage - 1), this.pagesize * this.currentPage)
      })
      this.loading = false
    },
    async add (data) {
      await addproject(data).then((res) => {
        console.log(res.success)
        if (res.success === true) {
          this.$message({
            type: 'success',
            showClose: true,
            message: '产品添加成功'
          })
          this.getinfomation()
          this.AddProjectInfo.newProjectName = ''
          this.AddProjectInfo.newProjectDescript = ''
          this.showDialog = false
        } else {
          this.$message({
            type: 'error',
            showClose: true,
            message: res.errormsg
          })
        }
      })
    },
    addprojects () {
      this.$refs.AddProjectInfo.validate((valid) => {
        if (valid) {
          var data = { projectName: this.AddProjectInfo.newProjectName, projectDescript: this.AddProjectInfo.newProjectDescript }
          // console.log(data)
          this.add(data)
        } else {
          this.$message({
            type: 'error',
            showClose: true,
            message: '请输入产品代码和产品描述'
          })
        }
      })
    }
  },
  watch: {
    searchInput (curVal, oldVal) {
      // console.log('curVal:' + curVal)
      this.loading = true
      var result = new Set()
      this.table.forEach(element => {
        // console.log(element['projectName'])
        if (element['projectName'].indexOf(curVal) !== -1) {
          result.add(element)
        }
      })
      this.tableSearchResult = Array.from(result)
      this.currentPage = 1
      this.tableData = this.tableSearchResult.slice(this.pagesize * (this.currentPage - 1), this.pagesize * this.currentPage)
      this.loading = false
    }
  },
  mounted () {
    this.getinfomation()
  }
}
</script>

<style lang="scss" scoped>
.container {
  height: 100%;
  .main {
    height: 100px;
    .information {
      margin-left: 5%;
      height: 70px;
      line-height: 70px;
      .title {
        font-size: 20px;
      }
    }
    .infor {
      margin-left: 5%;
      margin-bottom: 20px;
      .search {
        float: right;
        width: 200px;
        margin-right: 10%;
      }
    }
    .tableSet {
      height: calc(100vh - 60px - 160px - 60px - 60px);
    }
    .data {
      width: 90%;
      margin-left: 5%;
    }
  }
  .page {
    height: 40px;
    line-height: 40px;
    text-align: center;
  }
}
.add-dialog {
  height: 300px;
  font-size: 15px;
  background-color: #eceaea;
  .dialog-content {
    padding: 40px 0px 20px 50px;
    font-size: 16px;
    height: 40px;
    line-height: 40px;
    font-weight: bold;
    .dialog-code {
      width: 300px;
    }
    .dialog-descript {
      width: calc(100% - 20px);
    }
  }
}
</style>

<style lang="scss">
.sqldetail .el-dialog__header {
  padding: 0px 0px 0px 0px;
  font-size: 25px;
  text-align: center;
  background-color: gray;
  font-weight: bold;
  color: white;
  height: 60px;
  line-height: 60px;
}
</style>
