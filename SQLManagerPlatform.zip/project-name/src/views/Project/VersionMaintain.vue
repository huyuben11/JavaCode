<template>
  <el-container class="container">
    <el-main>
      <el-row class="main">
        <el-row class="information">
          <span class="title">
            <a href="#/project" class="linktext">产品列表</a> > {{projectname}}
          </span>
        </el-row>
        <el-row class="infor" :span="24">
          <el-col :span="12">
            <el-button type="primary" class="button" @click="showAddDialog=true" round>＋新增版本</el-button>
          </el-col>
          <el-col :span="12">
            <el-input placeholder="请输入内容" class="search" suffix-icon="el-icon-search" v-model="searchInput"/>
          </el-col>
        </el-row>
        <el-row class="tableSet" v-loading="loading">
          <el-table :data="tableData" class="data"  max-height="500">
            <el-table-column prop="versionName" label="版本代码" />
            <el-table-column prop="versionDescript" label="版本描述" />
            <el-table-column prop="crttime" label="创建时间" />
            <el-table-column prop="commitTime" label="最近提交时间" />
            <el-table-column prop="stop" label="是否停用">
              <template slot-scope="scope">
                <el-switch v-model="scope.row.menusstate" active-color="#13ce66" @change="changeStatus(scope.row)"/>
              </template>
            </el-table-column>
            <el-table-column prop="operation" label="操作" width="180">
              <template slot-scope="scope">
                <el-button @click="showEditDialog=true, handleEditVersion(scope.$index,scope.row)" icon="el-icon-edit" />
              </template>
            </el-table-column>
          </el-table>
        </el-row>
        <el-dialog
          class="sqldetail"
          :visible.sync="showEditDialog"
          append-to-body>
          <div slot="title">
            修改
          </div>
          <div class="add-dialog">
            <el-form :model="editVersionInfo" ref="editVersionInfo" :rules="editVersionRule">
              <el-row class="dialog-content" :span="24">
                <el-col :span="3">
                  <span>
                    产品代码
                  </span>
                </el-col>
                <el-col :span="21">
                  <el-form-item>
                    <el-input class="dialog-code" v-model="projectname" placeholder="产品代码" :disabled="true"/>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row class="dialog-content" :span="24">
                <el-col :span="3">
                  <span>
                    版本代码
                  </span>
                </el-col>
                <el-col :span="21">
                  <el-form-item prop="versionname" >
                    <el-input v-model="editVersionInfo.versionname" class="dialog-code" placeholder="版本代码" :disabled="true" />
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row class="dialog-content" :span="24">
                <el-col :span="3">
                  <span>
                    版本描述
                  </span>
                </el-col>
                <el-col :span="21">
                  <el-form-item prop="versiondescript" >
                    <el-input v-model="editVersionInfo.versiondescript" class="dialog-descript" placeholder="版本描述" />
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
          </div>
          <div slot="footer">
            <el-button type="primary" @click="updateversionFunc()">
              保&nbsp;存
            </el-button>
            <el-button  @click="showEditDialog = false">
              取&nbsp;消
            </el-button>
          </div>
        </el-dialog>
        <el-dialog
          class="sqldetail"
          :visible.sync="showAddDialog"
          append-to-body>
          <div slot="title">
            新增版本
          </div>
          <div class="add-dialog">
            <el-form :model="addVersionInfo" ref="addVersionInfo" :rules="addVersionRule">
              <el-row class="dialog-content" :span="24">
                <el-col :span="3">
                  <span>
                    产品代码
                  </span>
                </el-col>
                <el-col :span="21">
                  <el-form-item>
                    <el-input class="dialog-code" v-model="projectname" placeholder="产品代码" :disabled="true"/>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row class="dialog-content" :span="24">
                <el-col :span="3">
                  <span>
                    版本代码
                  </span>
                </el-col>
                <el-col :span="21">
                  <el-form-item prop="versionname" >
                    <el-input v-model="addVersionInfo.versionname" class="dialog-code" placeholder="版本代码" />
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row class="dialog-content" :span="24">
                <el-col :span="3">
                  <span>
                    版本描述
                  </span>
                </el-col>
                <el-col :span="21">
                  <el-form-item prop="versiondescript" >
                    <el-input v-model="addVersionInfo.versiondescript" class="dialog-descript" placeholder="版本描述" />
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
          </div>
          <div slot="footer">
            <el-button type="primary" @click="addversionFunc()">
              保&nbsp;存
            </el-button>
            <el-button  @click="showAddDialog = false">
              取&nbsp;消
            </el-button>
          </div>
          </el-dialog>
      </el-row>
    </el-main>
    <el-footer class="page">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        layout="prev, pager, next"
        :total="tableSearchResult.length"
        :page-size="pagesize">
      </el-pagination>
    </el-footer>
  </el-container>
</template>

<script>
import { editVersionHalt, getVersionInfo, addversion, updateversion } from '@/service/getVersionData'

export default {
  props: ['projectname'],
  data () {
    return {
      // 表格数据
      tableData: [],
      // 接口返回原始数据
      table: [],
      // 查询后结果数据
      tableSearchResult: [],
      // 查询字符串
      searchInput: '',
      // 当前页码
      currentPage: 1,
      // 总页数
      pagesize: 6,
      // 是否显示修改窗口
      showEditDialog: false,
      // 是否显示新增窗口
      showAddDialog: false,
      // 修改窗口数据源
      editVersionInfo: {
        versionname: '',
        versiondescript: ''
      },
      // 修改窗口验证规则
      editVersionRule: {
        versiondescript: [
          { required: true, message: '请输入版本描述', trigger: 'blur' }
        ]
      },
      // 新增窗口数据源
      addVersionInfo: {
        versionname: '',
        versiondescript: ''
      },
      // 新增窗口验证规则
      addVersionRule: {
        versionname: [
          { required: true, message: '请输入版本代码', trigger: 'blur' }
        ],
        versiondescript: [
          { required: true, message: '请输入版本描述', trigger: 'blur' }
        ]
      },
      // 是否显示加载状态
      loading: false
    }
  },
  methods: {
    changeStatus (rowObject) {
      var data = { project: this.projectname, version: rowObject.versionName, halt: rowObject.menusstate }
      var msg = rowObject.versionName + (rowObject.menusstate ? '启用' : '停用')
      this.editVersionHaltfunc(data, msg)
    },
    async editVersionHaltfunc (data, msg) {
      this.loading = true
      await editVersionHalt(data).then(res => {
        if (res.success === true) {
          this.$message({
            type: 'success',
            showClose: true,
            message: msg + '成功'
          })
        } else {
          this.$message({
            type: 'error',
            showClose: true,
            message: res.errormsg
          })
          this.getinfomation()
        }
      })
      this.loading = false
    },
    handleEditVersion (index, row) {
      this.editVersionInfo.versionname = row.versionName
      this.editVersionInfo.versiondescript = row.versionDescript
      console.log(this.editVersionInfo)
    },
    handleSizeChange (val) {
      console.log(`每页 ${val} 条`)
    },
    handleCurrentChange (val) {
      this.currentPage = val
      this.tableData = this.tableSearchResult.slice(this.pagesize * (this.currentPage - 1), this.pagesize * this.currentPage)
    },
    async getinfomation () {
      this.loading = true
      var data = { projectname: this.projectname }
      await getVersionInfo(data).then((res) => {
        this.table = res.tableData
        this.tableSearchResult = this.table
        this.tableData = this.tableSearchResult.slice(this.pagesize * (this.currentPage - 1), this.pagesize * this.currentPage)
      })
      this.loading = false
    },
    addversionFunc () {
      this.$refs.addVersionInfo.validate((valid) => {
        if (valid) {
          var data = { projectname: this.projectname, versionName: this.addVersionInfo.versionname, versionDescript: this.addVersionInfo.versiondescript }
          console.log(data)
          this.addVersionCall(data)
        } else {
          this.$message({
            type: 'error',
            showClose: true,
            message: '请输入版本代码和版本描述'
          })
        }
      })
    },
    async addVersionCall (data) {
      this.loading = true
      await addversion(data).then((res) => {
        if (res.success === true) {
          this.$message({
            type: 'success',
            showClose: true,
            message: '新增版本成功'
          })
          this.getinfomation()
          this.addVersionInfo.versionname = ''
          this.addVersionInfo.versiondescript = ''
          this.showAddDialog = false
        } else {
          this.$message({
            type: 'error',
            showClose: true,
            message: res.errormsg
          })
        }
      })
      this.loading = false
    },
    updateversionFunc () {
      this.$refs.editVersionInfo.validate((valid) => {
        if (valid) {
          var data = { projectname: this.projectname, versionname: this.editVersionInfo.versionname, versiondescript: this.editVersionInfo.versiondescript }
          this.updateversionCall(data, this.editVersionInfo.versionname)
        } else {
          this.$message({
            type: 'error',
            showClose: true,
            message: '请输入版本描述'
          })
        }
      })
    },
    async updateversionCall (data, msg) {
      this.loading = true
      await updateversion(data).then((res) => {
        if (res.success === true) {
          this.$message({
            type: 'success',
            showClose: true,
            message: msg + '修改成功'
          })
          this.getinfomation()
          this.showEditDialog = false
        } else {
          this.$message({
            type: 'error',
            showClose: true,
            message: res.errormsg
          })
        }
      })
      this.loading = false
    }
  },
  mounted () {
    this.getinfomation()
  },
  watch: {
    searchInput (curVal, oldVal) {
      this.loading = true
      var result = new Set()
      this.table.forEach(element => {
        // console.log(element['versionName'])
        if (element['versionName'].indexOf(curVal) !== -1) {
          result.add(element)
        }
      })
      this.tableSearchResult = Array.from(result)
      this.currentPage = 1
      this.tableData = this.tableSearchResult.slice(this.pagesize * (this.currentPage - 1), this.pagesize * this.currentPage)
      this.loading = false
    }
  }
}
</script>

<style lang="scss" scoped>
.container {
  height: 100%;
  .main {
    height: 100px;
    .information {
      margin-left: 5%;
      height: 70px;
      line-height: 70px;
      .title {
        font-size: 20px;
        .linktext {
          text-decoration: none;
          cursor: pointer;
          color: #2d8cf0;
        }
      }
    }
    .infor {
      margin-left: 5%;
      margin-bottom: 20px;
      .search {
        float: right;
        width: 200px;
        margin-right: 10%;
      }
    }
    .tableSet {
      height: calc(100vh - 60px - 160px - 60px - 60px);
    }
    .data {
      width: 90%;
      margin-left: 5%;
    }
  }
  .page {
    height: 40px;
    line-height: 40px;
    text-align: center;
  }
}
.add-dialog {
  height: 300px;
  font-size: 15px;
  background-color: #eceaea;
  .dialog-content {
    padding: 40px 0px 20px 50px;
    font-size: 16px;
    height: 40px;
    line-height: 40px;
    font-weight: bold;
    .dialog-code {
      width: 300px;
    }
    .dialog-descript {
      width: calc(100% - 20px);
    }
  }
}
</style>

<style lang="scss">
.sqldetail .el-dialog__header {
  padding: 0px 0px 0px 0px;
  font-size: 25px;
  text-align: center;
  background-color: gray;
  font-weight: bold;
  color: white;
  height: 60px;
  line-height: 60px;
}
</style>
