<template>
  <div class="foot">
    Powered by WestSoft ©
  </div>
</template>

<script>
export default {

}
</script>

<style>
.foot{
  font-size: 8px;
  text-align: center;
  color: #aaa;
}
</style>
