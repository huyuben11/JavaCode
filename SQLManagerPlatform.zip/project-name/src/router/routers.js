const DrawLayoutPanel = r => require.ensure([], () => r(require('@/components/DrawLayoutPanel')), 'DrawLayoutPanel')
const Login = r => require.ensure([], () => r(require('@/views/login/Login')), 'Login')
const Home = r => require.ensure([], () => r(require('../views/home/Home')), 'Home')
const Commit = r => require.ensure([], () => r(require('../views/SQLPage/Commit')), 'Commit')
const Query = r => require.ensure([], () => r(require('../views/SQLPage/Query')), 'Query')
const Export = r => require.ensure([], () => r(require('../views/SQLPage/Export')), 'Export')
const ProjectMaintain = r => require.ensure([], () => r(require('../views/Project/ProjectMaintain')), 'ProjectMaintain')
const Auth = r => require.ensure([], () => r(require('../views/Auth/Auth')), 'Auth')
const Users = r => require.ensure([], () => r(require('../views/Users/Users')), 'Users')
const VersionMaintain = r => require.ensure([], () => r(require('../views/Project/VersionMaintain')), 'VersionMaintain')

let routes = [
  {
    path: '/',
    component: DrawLayoutPanel,
    children: [
      {
        path: '/',
        component: Home
      },
      {
        path: '/home',
        component: Home
      },
      {
        path: '/commit',
        component: Commit
      },
      {
        path: '/query',
        component: Query
      },
      {
        path: '/export',
        component: Export
      },
      {
        path: '/project',
        component: ProjectMaintain
      },
      {
        path: '/project/:projectname/version',
        name: 'versionmaintain',
        component: VersionMaintain,
        props: true
      },
      {
        path: '/auth',
        component: Auth
      },
      {
        path: '/users',
        component: Users
      }
    ]
  },
  {
    path: '/login',
    component: Login,
    hidden: true
  }
]

export default routes
